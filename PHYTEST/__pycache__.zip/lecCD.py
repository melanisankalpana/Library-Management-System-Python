class LectureCD:
    def __init__(self, cd_no, title, subject, rental_price, copies):
        self.cd_no = cd_no
        self.title = title
        self.subject = subject
        self.rental_price = rental_price
        self.copies = copies
