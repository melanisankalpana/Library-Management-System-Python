class DVD:
    def __init__(self, dvd_no, title, subject, rental_price, copies):
        self.dvd_no = dvd_no
        self.title = title
        self.subject = subject
        self.rental_price = rental_price
        self.copies = copies