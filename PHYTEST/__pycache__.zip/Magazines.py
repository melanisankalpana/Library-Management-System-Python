class magazines:
    def __init__(self, mgzn_no, title, color, subject, rental_price, copies):
        self.mgzn_no = mgzn_no
        self.title = title
        self.color = color
        self.subject = subject
        self.rental_price = rental_price
        self.copies = copies